export function kalkulator(angka1, angka2, operator) {
    let hasil;

    if (isNaN(angka1) || isNaN(angka2)) {
    	return "Input harus berupa angka!";
    }

    switch (operator) {
        case "+":
            hasil = angka1 + angka2;
            break;
        case "-":
            hasil = angka1 - angka2;
            break;
        case "*":
            hasil = angka1 * angka2;
            break;
        case "/":
            if (angka2 === 0) {
                return "Error: Pembagian dengan nol!";
            }
            hasil = angka1 / angka2;
            break;
        default:
            return "Operator tidak valid!";
    }

    return hasil;
}